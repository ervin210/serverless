# Security Policy

## Supported Versions
The following versions of this software are actively supported with security updates:

| Version | Supported          |
| ------- | ------------------ |
| 1.0.x   | :white_check_mark: |
| < 1.0   | :x: |

## Security Best Practices
- Enforces **Bitdefender**-inspired cybersecurity measures.
- Uses **Quantum encryption** principles for secure data storage.
- Includes **Apple Pay** and **Google Pay** secured transactions.
- Supports **Face ID authentication** for user verification.

## Reporting Security Issues
If you discover a security vulnerability, please report it via email: **Ervin210@icloud.com**.

## Watermark & NDA
This project is protected under **Ervin Remus Radosavlevici**'s copyright and trademark laws.
    